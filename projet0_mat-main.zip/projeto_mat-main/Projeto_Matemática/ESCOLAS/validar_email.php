<!doctype html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>VALIDAR - EMAIL</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
</head>

<body>
    <h2>ENVIAMOS UM CÓDIGO PARA SEU EMAIL</h2>
    <p>Insira abaixo o código que enviamos para que possamos confirmar o email associado ao cadastro da escola</p>
    <P>Após a confirmação, faremos uma verificação manual da extensão email antes de finalizar seu cadastro </p>

    <form class="" method="" post>
        <input type="text" id="cod_email" name="cod_email" required>
    </form>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI"
        crossorigin="anonymous"></script>
</body>

</html>