
<footer class="footer py-3 bg-dark  border-top">
    <div class="container-fluid text-center">
        <span class="text-muted">
            &copy; <?php echo date("Y/m/d"); ?>
        </span>
    </div>
</footer>